"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function HeroSection({ scrollToSection }: { scrollToSection: (id: string) => void }) {
  return (
    <section
      id="home"
      className="relative overflow-hidden bg-gradient-to-b from-background to-muted/50 dark:from-background dark:to-background py-16 md:py-24"
    >
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1600')] bg-cover bg-center opacity-10 dark:opacity-5"></div>
      <div className="container relative z-10">
        <div className="grid gap-8 md:grid-cols-2 md:gap-12 items-center">
          <div className="space-y-6">
            <Badge className="bg-[#0EA5E9] hover:bg-[#0EA5E9]/90 text-white">15% Off Your First Installation!</Badge>
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl text-[#3FA9F5] dark:text-[#5BC0EB] drop-shadow-sm">
              Stay Cool with Penguin Air-conditioning
            </h1>
            <p className="text-lg text-muted-foreground">
              Your #1 Choice for Air-Conditioning & Refrigeration in Port Elizabeth/Gqeberha. Need a cool breeze in the
              middle of summer? We've got you covered.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-[#0EA5E9] hover:bg-[#0EA5E9]/90 text-white"
                onClick={() => scrollToSection("contact")}
              >
                Cool Down Now!
              </Button>
              <Button size="lg" variant="outline" onClick={() => scrollToSection("services")}>
                View Services
              </Button>
            </div>
          </div>
          <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden shadow-xl">
            <div className="absolute inset-0 bg-gradient-to-tr from-[#3FA9F5]/20 to-transparent"></div>
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Avalanche Inverter R410A Air-conditioner"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  )
}

