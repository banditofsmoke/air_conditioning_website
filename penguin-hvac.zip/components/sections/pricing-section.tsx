"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { PricingCard } from "@/components/ui-cards"

export default function PricingSection({ scrollToSection }: { scrollToSection: (id: string) => void }) {
  return (
    <section
      id="pricing"
      className="py-16 bg-gradient-to-b from-background to-muted/50 dark:from-background dark:to-background/80"
    >
      <div className="container">
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-[#0EA5E9] hover:bg-[#0EA5E9]/90 text-white">Limited Time Offer</Badge>
          <h2 className="text-3xl font-bold text-[#3FA9F5] dark:text-[#5BC0EB]">New Year's Cooling Special</h2>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            Avalanche Inverter R410A Air-Conditioners - All units include 3m pipe kit and connecting cables.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          <PricingCard btu="12,000 BTU" price="R7,442" onClick={() => scrollToSection("contact")} />
          <PricingCard btu="18,000 BTU" price="R7,929" onClick={() => scrollToSection("contact")} />
          <PricingCard btu="24,000 BTU" price="R10,533" onClick={() => scrollToSection("contact")} />
          <PricingCard btu="30,000 BTU" price="R14,131" onClick={() => scrollToSection("contact")} />
          <PricingCard btu="36,000 BTU" price="R17,185" onClick={() => scrollToSection("contact")} />
        </div>
        <div className="mt-8 text-center">
          <Button
            size="lg"
            className="bg-[#0EA5E9] hover:bg-[#0EA5E9]/90 text-white"
            onClick={() => scrollToSection("contact")}
          >
            Get Your Quote Today
          </Button>
        </div>
      </div>
    </section>
  )
}

